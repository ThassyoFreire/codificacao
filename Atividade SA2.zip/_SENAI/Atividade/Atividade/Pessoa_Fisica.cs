namespace ATividade
{
    class Pessoa_Fisica : Clientes
    {
        public string cpf;
        public string rg;
    }
}